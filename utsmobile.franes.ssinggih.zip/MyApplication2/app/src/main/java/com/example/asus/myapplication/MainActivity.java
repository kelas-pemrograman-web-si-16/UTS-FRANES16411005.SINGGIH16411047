import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
public class MainActivity extends Activity {
    /** Called when the activity is first created. */
    int gajiST, gajiPerJam;
    RadioButton jm1, jm2, jm3, jm4;
    RadioGroup JamKerjaLembur;
    Button hitung;
    CheckBox jeke;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void hitung(View v) {
        EditText nama = (EditText) findViewById(R.id.nama);
        TextView outputNama = (TextView) findViewById(R.id.outputNama);
        String name = nama.getText().toString();
        outputNama.setText("Total Gaji " + name);
        jeke = (CheckBox) findViewById(R.id.laki);
        if (jeke.isChecked()) {
            gajiST = 1500000;
        }
        ;
        JamKerjaLembur = (RadioGroup) findViewById(R.id.rgGolongan);
        int jm = JamKerjaLembur.getCheckedRadioButtonId();
        if (jm == R.id.rbGolongan1) {
            gajiPerJam = 7000;
        } else if (jm == R.id.rbGolongan2) {
            gajiPerJam = 14000;
        } else if (jm == R.id.rbGolongan3){
            gajiPerJam = 21000;
        } else if (jm == R.id.rbGolongan4){
            gajiPerJam = 28000;
        }
        ;
        int totalGaji = gajiST + gajiPerJam;
        TextView total = (TextView) findViewById(R.id.outputGaji);
        total.setText(String.valueOf(totalGaji));